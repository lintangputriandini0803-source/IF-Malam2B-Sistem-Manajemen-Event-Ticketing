<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    public function showLoginForm()
    {
        return view('home');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email'    => 'required|email',
            'password' => 'required',
        ]);

        if (Auth::attempt($credentials, $request->boolean('remember'))) {
            $request->session()->regenerate();

            $user = Auth::user();

            if ($user->isAdmin()) {
                return redirect()->route('admin.dashboard')->with('success', 'Login Sebagai Admin Berhasil');
            }

            if ($user->isPanitia() && $user->isApproved()) {
                return redirect()->route('panitia.dashboard')->with('success', 'Login Sebagai Panitia Berhasil');;
            }

            // Panitia pending/rejected
            Auth::logout();
            return redirect('/')->with('login_error', 'Akun kamu belum disetujui admin.');
        }

        return redirect('/')->with('login_error', 'Email atau password salah');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/')->with('info', 'Anda Berhasil Logout');
    }
}
